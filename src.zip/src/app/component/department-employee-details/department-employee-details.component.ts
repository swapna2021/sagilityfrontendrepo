import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-employee-details',
  templateUrl: './department-employee-details.component.html',
  styleUrls: ['./department-employee-details.component.css']
})
export class DepartmentEmployeeDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
