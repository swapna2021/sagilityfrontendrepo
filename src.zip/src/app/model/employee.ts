import { Department } from "./deartment";

export class Employee {
id !: number;
name! : string;
dob!:string;
phone!:string;
email! : string;
address!: string;
salary!:number;
department!:Department;


}
