import { Deartment } from './deartment';

describe('Deartment', () => {
  it('should create an instance', () => {
    expect(new Deartment()).toBeTruthy();
  });
});
